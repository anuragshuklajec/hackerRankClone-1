apienv\Scripts\activate
cd C:\Users\vc8bp\OneDrive\Desktop\Newfolder\backend\myproject 
python manage.py runserver 0.0.0.0:8000