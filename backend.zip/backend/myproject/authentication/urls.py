from django.urls import path

from .views import *


urlpatterns = [
    path('getAllUsers',usersApi), 
    path('createUser',usersApi),
    path('login',userSession),
    path('logout',userSession),
    path('delSession',userSession),
    path('checkSession',checkUserSession),
    path('dummyFunction',dummyFunction),

]
