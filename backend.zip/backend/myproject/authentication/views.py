from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from myapp.models import *
from django.core import serializers
import json
from django.views.decorators.csrf import csrf_exempt
from .utils import *  
import traceback
import time,json,logging
from rest_framework import status
from authentication.decorators import checkSession,admin_required




@csrf_exempt 
def usersApi(request):
    msg={"status":"","errorCode":"","reason":"","result":"","transactionID":0,"redirectURL":"","httpStatus":status.HTTP_200_OK}
    msg['transactionID']=time.time()
    
    if request.method == "POST":        
        try : 
            data = json.loads(request.body)
            
            if data.get('event')=='create': 
                resultset = createUser(request)
                msg["status"]="success" 
                msg["result"]=resultset  
                return JsonResponse(data=msg,safe=False,status=msg["httpStatus"])

            else :
                msg["status"]="error"
                msg["reason"]=str(e)
                msg["errorCode"]=400
                return JsonResponse(data=msg,safe=False,status=msg["httpStatus"])

        except Exception as e :   
            msg["status"]="error"
            msg["reason"]=str(e)
            msg["errorCode"]=500
            return JsonResponse(data=msg,safe=False,status=msg["httpStatus"])

    try : 
        print("here")
        msg['result']=getAllUsersList(request)
        msg["status"]="success"
        return JsonResponse(msg,safe=False,status=msg["httpStatus"])

    except Exception as e :
        msg["status"]="error"
        msg["reason"]=str(e)
        msg["errorCode"]=500
        return JsonResponse(msg,safe=False,status=msg["httpStatus"])


@csrf_exempt
def userSession(request):
    msg={"status":"","errorCode":"","reason":"","result":"","transactionID":0,"redirectURL":"","httpStatus":status.HTTP_200_OK}
    msg['transactionID']=time.time()

    if request.method=="POST" :
        try:
            body = json.loads(request.body)  
            print(body)
            if len(body)>0 :
                if body.get('event') == 'delSession':
                    # print(body)
                    if delRemoteSession(body.get('data').get('email')) :
                        msg["status"]="success"        
                        msg["result"]="Succefully logged out from another machin"                      
                        return JsonResponse(msg,safe=False,status=msg["httpStatus"])

                if body.get('event') == 'login' :
                    # CHECKING IF ACCOUNT IS DISABLED
                    if isAccountDisabled(email=body.get("data").get("email")):
                        msg["status"]="error"
                        msg["reason"]="Your account is disabled !! Contact your administrator!"
                        msg["errorCode"]=104
                        msg["httpStatus"]=status.HTTP_401_UNAUTHORIZED
                        return JsonResponse(msg,safe=False,status=msg["httpStatus"])

                    request.session.clear_expired()
                    if 'email' in request.session.keys() : 
                        msg["status"]="error"
                        msg["reason"]="You are already logged in!!"
                        msg["errorCode"]=100
                        return JsonResponse(msg,safe=False,status=msg["httpStatus"])
                    print("good")
                    result = checkPassword(request)
                    print("Printing result",result)
                
                    if  result.get('auth',False) :
                        if isSessionActive(body.get('data').get('email')) :
                            print("already logged in!!")
                            msg["status"]="error"
                            msg["reason"]="User is already Logged in on another machin!!"
                            msg["errorCode"]=105
                            msg["result"] = {"alreadyactive":True}
                            msg["httpStatus"]=status.HTTP_401_UNAUTHORIZED
                            return JsonResponse(msg,safe=False,status=msg["httpStatus"])
            

                        isAdmin = createSession(request)
                        msg["status"]="success"    
                        data = {}  
                        if isAdmin: 
                            
                            data["defaultlandingpage"]='admindashboard'
                            data["profile"]=getUsersProfile(body.get('data').get('email'))
                            msg["result"]="Set Here Your Private Routes"
                                            
                        else :
                            data["defaultlandingpage"]='tradingdashboard'
                            data["profile"]=getUsersProfile(body.get('data').get('email'))
                            msg["result"]="Set Here your Private Routes"       

                    else :
                        msg["status"]="error"
                        msg["reason"]="authentication unsucessfull!"
                        msg["errorCode"]=102
                        msg["httpStatus"]=status.HTTP_401_UNAUTHORIZED

                        


                else :
                    msg["status"]="error"
                    msg["reason"]="Invalid Request !!"
                    msg["errorCode"]=103 
                    msg["httpStatus"]=status.HTTP_400_BAD_REQUEST
                    
            else :
                msg["status"]="error"
                msg["reason"]="recieved blank body!!"
                msg["errorCode"]=501 
                msg["httpStatus"]=status.HTTP_400_BAD_REQUEST
                
                
                
        except Exception as e:
            print(e)
            msg["status"]="error"
            msg["reason"]=str(e)
            msg["errorCode"]=500
            msg["httpStatus"]=status.HTTP_500_INTERNAL_SERVER_ERROR
        return JsonResponse(msg,safe=False,status=msg["httpStatus"])

    
    try:
        if request.GET['event'] == 'logout' :
            logout(request)
            msg["status"]="success"        
            msg["result"]="user logged out!"
        elif request.GET['event'] == 'checkSession' :
            if checkSession(request) :                 
                isAdmin = request.session['isAdmin']
                msg["status"]="success"    
                data = {}  
                if isAdmin:  
                    data["defaultlandingpage"]='admindashboard'
                    msg["result"]="Set Here Your Private Routes"              
                else :
                    data["defaultlandingpage"]='tradingdashboard'
                    msg["result"]="Set Here your Private Routes"     

            else :
                msg["status"]="error"
                msg["reason"]="Unauthorized. Please login or register first!!!"
                msg["errorCode"]=101
                msg["httpStatus"]=status.HTTP_401_UNAUTHORIZED
        else :
            msg["status"]="error"
            msg["reason"]="Invalid Request !!"
            msg["errorCode"]=103 
            msg["httpStatus"]=status.HTTP_400_BAD_REQUEST

    except Exception as e:
        msg["status"]="error"
        msg["reason"]=str(e)
        msg["errorCode"]=500
        msg["httpStatus"]=status.HTTP_500_INTERNAL_SERVER_ERROR
       
    return JsonResponse(msg,safe=False,status=msg["httpStatus"])


@csrf_exempt
def checkUserSession(request):
    msg={"status":"","errorCode":"","reason":"","result":"","transactionID":0,"redirectURL":"","httpStatus":status.HTTP_200_OK}
    msg['transactionID']=time.time()    
    try:
        if 'ID' not in request.session.keys() :  
            msg["status"]="error"
            msg["reason"]="Unauthorized. Please login or register first!!!"
            msg["errorCode"]=101      
            return JsonResponse(data=msg,safe=False)


        if isAccountDisabled(email=request.session["email"]):
            msg["status"]="error"
            msg["reason"]="Your account is disabled !! Contact your administrator!"
            msg["errorCode"]=104
            msg["httpStatus"]=status.HTTP_401_UNAUTHORIZED
            return JsonResponse(msg,safe=False,status=msg["httpStatus"])

        if checkSession(request) :                 
            isAdmin = request.session['isAdmin']
            msg["status"]="success"    
            data = {}  
            if isAdmin:  
                data["defaultlandingpage"]='admindashboard'
                msg["result"]="Set Here Your Private Routes"              
            else :
                data["defaultlandingpage"]='tradingdashboard'
                msg["result"]="Set Here your Private Routes"          
        else :
            msg["status"]="error"
            msg["reason"]="Unauthorized. Please login or register first!!!"
            msg["errorCode"]=101      
            msg["httpStatus"]=status.HTTP_401_UNAUTHORIZED
    
    except Exception as e:
        print(e)
        msg["status"]="error"
        msg["reason"]=str(e)
        msg["errorCode"]=500
        msg["httpStatus"]=status.HTTP_500_INTERNAL_SERVER_ERROR
    return JsonResponse(msg,safe=False,status=msg["httpStatus"])



@csrf_exempt
@admin_required
def dummyFunction(request):
    msg={"status":"","errorCode":"","reason":"","result":"","transactionID":0,"redirectURL":"","httpStatus":status.HTTP_200_OK}
    msg['transactionID']=time.time()
    if request.method == 'POST':
        msg["status"]="success"
        msg["result"]="Hurray you are admin"
        msg["httpStatus"]=200
        return JsonResponse(msg,safe=False,status=msg["httpStatus"])